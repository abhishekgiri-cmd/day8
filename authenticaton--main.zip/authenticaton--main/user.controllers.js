const express = require("express");
const { find } = require("../models/user.model");

const router = express.Router()





module.exports = router